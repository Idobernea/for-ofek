﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 mainGame = new Form1();
            mainGame.Show();
            results.Text = vehicleName.Text;
            if(vehicleType_car.Checked)
            {
                Car car = new Car(vehicleName.Text);
                //ADD if sport or normal
                mainGame.setMainVehicle(car);
                mainGame.setMainVehicle(new SportCar(vehicleName.Text, 10));
            } 
            else if (vehicleType_motor.Checked)
            {
                mainGame.setMainVehicle(new MotorCycle(vehicleName.Text));
            }
            
            

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            colorsSelect.Items.Clear();
            if (cartype.SelectedItem.ToString() == "Sport")
            {
                colorsSelect.Items.Add("Blue");
                colorsSelect.Items.Add("Yellow");
            } else if (cartype.SelectedItem.ToString() == "Regular")
            {
                colorsSelect.Items.Add("White");
                colorsSelect.Items.Add("Red");
            }
           
        }

        private void vehicleType_motor_CheckedChanged(object sender, EventArgs e)
        {
            cartype.Visible = false;
            colorsSelect.Visible = false;
            textcartype.Visible = false;
            textcarcolor.Visible = false;
            textmotorcolor.Visible = true;
            motorcolorbox.Visible = true;
            
            
        }

        private void vehicleType_car_CheckedChanged(object sender, EventArgs e)
        {
            cartype.Visible = true;
            colorsSelect.Visible = true;
            textcartype.Visible = true;
            textcarcolor.Visible = true;
            motorcolorbox.Visible = false;
            textmotorcolor.Visible = false;
        }

        private void motorcolorbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void colorsSelect_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if(colorsSelect.Text=="White")
            {
                

            }
        }
    }
}

﻿
namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vehicleType_motor = new System.Windows.Forms.RadioButton();
            this.vehicleType_car = new System.Windows.Forms.RadioButton();
            this.vehicleName = new System.Windows.Forms.TextBox();
            this.textVtype = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Submit = new System.Windows.Forms.Button();
            this.results = new System.Windows.Forms.Label();
            this.cartype = new System.Windows.Forms.ComboBox();
            this.colorsSelect = new System.Windows.Forms.ComboBox();
            this.textcarcolor = new System.Windows.Forms.Label();
            this.textcartype = new System.Windows.Forms.Label();
            this.textmotorcolor = new System.Windows.Forms.Label();
            this.motorcolorbox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // vehicleType_motor
            // 
            this.vehicleType_motor.AutoSize = true;
            this.vehicleType_motor.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.vehicleType_motor.Location = new System.Drawing.Point(531, 49);
            this.vehicleType_motor.Name = "vehicleType_motor";
            this.vehicleType_motor.Size = new System.Drawing.Size(132, 26);
            this.vehicleType_motor.TabIndex = 18;
            this.vehicleType_motor.TabStop = true;
            this.vehicleType_motor.Text = "MotorCycle";
            this.vehicleType_motor.UseVisualStyleBackColor = true;
            this.vehicleType_motor.CheckedChanged += new System.EventHandler(this.vehicleType_motor_CheckedChanged);
            // 
            // vehicleType_car
            // 
            this.vehicleType_car.AutoSize = true;
            this.vehicleType_car.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.vehicleType_car.Location = new System.Drawing.Point(178, 49);
            this.vehicleType_car.Name = "vehicleType_car";
            this.vehicleType_car.Size = new System.Drawing.Size(62, 26);
            this.vehicleType_car.TabIndex = 17;
            this.vehicleType_car.TabStop = true;
            this.vehicleType_car.Text = "Car";
            this.vehicleType_car.UseVisualStyleBackColor = true;
            this.vehicleType_car.CheckedChanged += new System.EventHandler(this.vehicleType_car_CheckedChanged);
            // 
            // vehicleName
            // 
            this.vehicleName.Location = new System.Drawing.Point(166, 220);
            this.vehicleName.Name = "vehicleName";
            this.vehicleName.Size = new System.Drawing.Size(125, 27);
            this.vehicleName.TabIndex = 19;
            // 
            // textVtype
            // 
            this.textVtype.AutoSize = true;
            this.textVtype.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textVtype.Location = new System.Drawing.Point(21, 49);
            this.textVtype.Name = "textVtype";
            this.textVtype.Size = new System.Drawing.Size(114, 21);
            this.textVtype.TabIndex = 20;
            this.textVtype.Text = "Vehicle type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(41, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 21);
            this.label2.TabIndex = 21;
            this.label2.Text = "Vehicle name";
            // 
            // Submit
            // 
            this.Submit.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Submit.Location = new System.Drawing.Point(41, 344);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(94, 29);
            this.Submit.TabIndex = 22;
            this.Submit.Text = "submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.button1_Click);
            // 
            // results
            // 
            this.results.AutoSize = true;
            this.results.Location = new System.Drawing.Point(83, 321);
            this.results.Name = "results";
            this.results.Size = new System.Drawing.Size(0, 20);
            this.results.TabIndex = 23;
            // 
            // cartype
            // 
            this.cartype.FormattingEnabled = true;
            this.cartype.Items.AddRange(new object[] {
            "Sport",
            "Regular"});
            this.cartype.Location = new System.Drawing.Point(166, 112);
            this.cartype.Name = "cartype";
            this.cartype.Size = new System.Drawing.Size(115, 28);
            this.cartype.TabIndex = 24;
            this.cartype.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedValueChanged);
            // 
            // colorsSelect
            // 
            this.colorsSelect.FormattingEnabled = true;
            this.colorsSelect.Items.AddRange(new object[] {
            "Sport",
            "Regular"});
            this.colorsSelect.Location = new System.Drawing.Point(166, 160);
            this.colorsSelect.Name = "colorsSelect";
            this.colorsSelect.Size = new System.Drawing.Size(115, 28);
            this.colorsSelect.TabIndex = 25;
            this.colorsSelect.SelectionChangeCommitted += new System.EventHandler(this.colorsSelect_SelectionChangeCommitted);
            // 
            // textcarcolor
            // 
            this.textcarcolor.AutoSize = true;
            this.textcarcolor.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textcarcolor.Location = new System.Drawing.Point(41, 160);
            this.textcarcolor.Name = "textcarcolor";
            this.textcarcolor.Size = new System.Drawing.Size(53, 21);
            this.textcarcolor.TabIndex = 26;
            this.textcarcolor.Text = "color";
            // 
            // textcartype
            // 
            this.textcartype.AutoSize = true;
            this.textcartype.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textcartype.Location = new System.Drawing.Point(41, 112);
            this.textcartype.Name = "textcartype";
            this.textcartype.Size = new System.Drawing.Size(82, 21);
            this.textcartype.TabIndex = 27;
            this.textcartype.Text = "car Type";
            // 
            // textmotorcolor
            // 
            this.textmotorcolor.AutoSize = true;
            this.textmotorcolor.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textmotorcolor.Location = new System.Drawing.Point(435, 114);
            this.textmotorcolor.Name = "textmotorcolor";
            this.textmotorcolor.Size = new System.Drawing.Size(53, 21);
            this.textmotorcolor.TabIndex = 28;
            this.textmotorcolor.Text = "color";
            // 
            // motorcolorbox
            // 
            this.motorcolorbox.FormattingEnabled = true;
            this.motorcolorbox.Items.AddRange(new object[] {
            "Green",
            "Purple"});
            this.motorcolorbox.Location = new System.Drawing.Point(531, 112);
            this.motorcolorbox.Name = "motorcolorbox";
            this.motorcolorbox.Size = new System.Drawing.Size(115, 28);
            this.motorcolorbox.TabIndex = 29;
            this.motorcolorbox.SelectedIndexChanged += new System.EventHandler(this.motorcolorbox_SelectedIndexChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.motorcolorbox);
            this.Controls.Add(this.textmotorcolor);
            this.Controls.Add(this.textcartype);
            this.Controls.Add(this.textcarcolor);
            this.Controls.Add(this.colorsSelect);
            this.Controls.Add(this.cartype);
            this.Controls.Add(this.results);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textVtype);
            this.Controls.Add(this.vehicleName);
            this.Controls.Add(this.vehicleType_motor);
            this.Controls.Add(this.vehicleType_car);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton vehicleType_motor;
        private System.Windows.Forms.RadioButton vehicleType_car;
        private System.Windows.Forms.TextBox vehicleName;
        private System.Windows.Forms.Label textVtype;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Label results;
        private System.Windows.Forms.ComboBox cartype;
        private System.Windows.Forms.ComboBox colorsSelect;
        private System.Windows.Forms.Label textcarcolor;
        private System.Windows.Forms.Label textcartype;
        private System.Windows.Forms.Label textmotorcolor;
        private System.Windows.Forms.ComboBox motorcolorbox;
    }
}
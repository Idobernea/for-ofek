﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        private Vehicle _mainVehicle;

        public void setMainVehicle(Vehicle vehicle)
        {
            _mainVehicle = vehicle;
            switch (_mainVehicle.getVecType())
            {
                case VehicleType.Car:
                    if (_mainVehicle.ToString)== "white")
                    {
                        whiteCar.Visible = true;
                    }
                   
                    //_mainVehicle.getSpeed()
                    break;
                case VehicleType.Motorcycle:
                    break;
                case VehicleType.SportCar:
                    // if(MainVehicle.getColor) ADD GeT COLOr in vehicle class
                    break;
            }
        }

        public Form1()
        {
            InitializeComponent();
            over.Visible = false;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            whiteCar.Visible = false;
            BlueCar.Visible = false;
            greenMotor.Visible = false;
            purpleMotor.Visible = false;
            yellowCar.Visible = false;
            redCar.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            moveLine(gameSpeed);
            coins(gameSpeed);
            coinscolletion();
            enemy(gameSpeed);
            gameOver();
        }
        void moveLine (int speed)
        {
            if(Line4.Top>=500)
            {
                Line4.Top = 0;
            }
            else
            {
                Line4.Top += speed;
            }
            if (Line3.Top >= 500)
            {
                Line3.Top = 0;
            }
            else
            {
                Line3.Top += speed;
            }
            if (Line1.Top >= 500)
            {
                Line1.Top = 0;
            }
            else
            {
                Line1.Top += speed;
            }
            if (Line2.Top >= 500)
            {
                Line2.Top = 0;
            }
            else
            {
                Line2.Top += speed;
            }
        

        }

        Random r = new Random();
        int x;
        int collectedCoins = 0;

        void enemy(int speed)
        {
            if (BOM1.Top >= 500)
            {
                x = r.Next(50,250);
                BOM1.Location = new Point(x, 0);
            }
            else
            {
               BOM1.Top += speed;
            }
            if (BOM2.Top >= 630)
            {
                x = r.Next(250,620) ;
                BOM2.Location = new Point(x, 0);
            }
            else
            {
                BOM2.Top += speed;
            }
        }

        void gameOver ()
        {
            if(whiteCar.Bounds.IntersectsWith(BOM1.Bounds))
            {
                timer1.Enabled = false;
                over.Visible = true;
            }
            if (whiteCar.Bounds.IntersectsWith(BOM2.Bounds))
            {
                timer1.Enabled = false;
                over.Visible = true;
            }

        }
        void coins (int speed)
        {
            if(coin1.Top>=500)
            {
                x = r.Next(150,315);
                coin1.Location = new Point(x, 0);
            }
            else
            {
                coin1.Top+= speed;
            }
            if (coin2.Top >= 500)
            {
                x = r.Next(150,315) ;
                coin2.Location = new Point(x, 0);
            }
            else
            {
                coin2.Top += speed;
            }
            if (coin3.Top >= 630)
            {
                x = r.Next(315, 620);
                coin3.Location = new Point(x, 0);
            }
            else
            {
                coin3.Top += speed;
            }
            if (coin4.Top >= 630)
            {
                x = r.Next(315,620);
                coin4.Location = new Point(x, 0);
            }
            else
            {
                coin4.Top += speed;
            }
        }
        void coinscolletion()
        {
            if(whiteCar.Bounds.IntersectsWith(coin1.Bounds))
            {
                collectedCoins++;
                label1.Text = "coins=" + collectedCoins.ToString();
                x = r.Next(50, 300);
                coin1.Location=new Point (x, 0);
            }
            if (whiteCar.Bounds.IntersectsWith(coin2.Bounds))
            {
                collectedCoins++;
                label1.Text = "coins=" + collectedCoins.ToString();
                coin2.Location = new Point(x, 0);
            }
            if (whiteCar.Bounds.IntersectsWith(coin3.Bounds))
            {
                collectedCoins++;
                label1.Text = "coins=" + collectedCoins.ToString();
                coin3.Location = new Point(x, 0);
            }
            if (whiteCar.Bounds.IntersectsWith(coin4.Bounds))
            {
                collectedCoins++;
                label1.Text = "coins=" + collectedCoins.ToString();
                coin4.Location = new Point(x, 0);
            }
        }

        int gameSpeed = 0;
        int type = 0;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (whiteCar.Left > 70)
                    whiteCar.Left += -8;
            }
            if (e.KeyCode == Keys.Right)
            {
                if (whiteCar.Left < 630)
                    whiteCar.Left += 8;
            }
            if (e.KeyCode == Keys.Up)
            {
                if (gameSpeed < 21)
                {
                    gameSpeed++;
                }
            }
            if (e.KeyCode == Keys.Down)
            {
                if (gameSpeed > 0)
                {
                    gameSpeed--;
                }
            }
       
        }

    }
 

}

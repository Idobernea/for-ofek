﻿
using static System.Console;
namespace WinFormsApp1
{
    using System;
    using System.Collections;

    public enum VehicleType
    {
        Motorcycle,
        Car,
        SportCar
    }
    
    public enum Color
    {
        red,
        white,
        yellow,
        blue,
        green,
        purple
    }

    [Serializable]
    public abstract class Vehicle
    {
        protected string _name;
        protected int _speed;
        protected VehicleType _vecType;
        protected Color _color;

        public string getName()
        {
            return _name;
        }

        public VehicleType getVecType()
        {
            return _vecType;
        }
        public int getSpeed()
        {
            return _speed;
        }
        public Color getColor()
        {
            return _color;
        }

    }

    [Serializable]
    public class Car : Vehicle
    {
     
        public Car(string name)
        {
            _name = name;
            _speed = 8;
            _vecType = VehicleType.Car;
            
        }
    }

    [Serializable]
    public class SportCar : Car
    {
        public SportCar(string name, int speed) : base(name)
        {
            _name = name;
            _speed = speed;
            _vecType = VehicleType.SportCar;
            
        }

    }

    [Serializable]
    public class MotorCycle : Vehicle
    {
        public MotorCycle(string name)
        {
            _name = name;
            _speed = 10;
            _vecType = VehicleType.Motorcycle;
        }
    }
    [Serializable]
    public class VehicleList
    {
        protected SortedList vehicle;

        public VehicleList()
        {
            vehicle = new SortedList();
        }
        public int NextIndex
        {
            get
            {
                return vehicle.Count;
            }
            //!!!
            // !! there is no set !!
        }
        public Vehicle this[int index]
        {
            get
            {
                if (index >= vehicle.Count)
                    return (Vehicle)null;
                //SortedList internal method
                return (Vehicle)vehicle.GetByIndex(index);
            }
            set
            {
                if (index <= vehicle.Count)
                    vehicle[index] = value; //!!!		
            }
        }
    }
}
